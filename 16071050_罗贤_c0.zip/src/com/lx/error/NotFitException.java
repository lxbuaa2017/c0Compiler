package com.lx.error;

public class NotFitException extends Exception{
    public NotFitException(String message) {
        super(message);
    }
}
