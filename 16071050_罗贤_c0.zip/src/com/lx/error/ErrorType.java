package com.lx.error;

public enum ErrorType {

}
